# Fitxers i Persistència

## Estructures de Dades i Algorismes (EDA) - 3r Trimestre

### Grau en Enginyeria Informàtica de Gestió i Estructura de Dades i Sistemes d'Informació (GEISI)

### Doble Grau en Informàtica de Gestió i Sistemes d'Informació/ Grau en Disseny i Producció de Videojocs (DB GEISI-GDPV)