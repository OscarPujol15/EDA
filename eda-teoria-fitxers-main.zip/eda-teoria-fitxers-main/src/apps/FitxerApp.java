package apps;

public class FitxerApp {
}
